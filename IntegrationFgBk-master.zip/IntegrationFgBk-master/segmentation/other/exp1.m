clear all
close all
clc

result = fun(3);
result
