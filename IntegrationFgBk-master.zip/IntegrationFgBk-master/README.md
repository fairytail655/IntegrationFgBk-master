# IntegrationFgBk

This is the implementation of paper "Background Subtraction for Freely Moving Camera via Integration of Foreground and Background Cues"

You may see some demo on
https://www.youtube.com/watch?v=C2nUw-dcDMU&t=5s
https://www.youtube.com/watch?v=0FtfRUZOZK8&t=35s
https://www.youtube.com/watch?v=ss4VIRWq6X8&t=236s

To run the source code, you need recompile all the .cpp files, and installed the VLFeat and MexOpencv.

we are still working on this implementation .


