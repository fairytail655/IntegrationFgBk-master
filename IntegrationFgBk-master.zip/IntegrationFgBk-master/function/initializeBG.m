function re_model = initializeBG(img);

re_model = {img};
